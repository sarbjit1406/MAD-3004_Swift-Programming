//
//  main.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var request1 = RequestLimitIncrease()

//do{
//try request1.processrequest(accountNo: "S1100")
//}catch limitIncreaseErrors.ineligible{
//    print("You don't have an account with our bank. Request rejected")
//}catch limitIncreaseErrors.noSavingAc{
//    print("Credit limit can only be increased if you have Saving Account.")
//}catch limitIncreaseErrors.insufficientBalance{
//print("You need minimum $5000 balance in your saving account to be eligible fpr credit limit increase.")
//}catch{
//    print("Service disrupte...Sorry for inconvenience.")
//}

do{
    try request1.processrequest(accountNo: "S1200")
}catch is limitIncreaseErrors{
    print("You are not matching with any of the following criteria")
    print("1. No account with bank \n2. No saving account \n3. Minimum $5000 in saving account")
}

//Static
var s1 = Student()
s1.name = "Sarb"
Student.acNo = 987
s1.display()

var s2 = Student()
s2.name = "Harpreet"
s2.display()
