//
//  Student.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
//class Student{
//final class Student{ // final class can never be inherited
//private class Student

class Student{
    var name: String?
    static var acNo: Int?
    
    init(){
        self.name = "Unknown"
        Student.acNo = 123456
    }
    func display(){
        print("Student name : \(self.name ?? "Unknown")")
        print("Account No : \(Student.acNo ?? 0)")
    }
    
    static func getAcNo() -> Int{
    //    var i = self.name
        return acNo!
    }
}

class PartTime: Student{
    var hours: Int?
    
    override init(){
        self.hours = 10
        super.init()
        }
    override func display() {
        print("Hours : \(self.hours ?? 10)")
    }
}
