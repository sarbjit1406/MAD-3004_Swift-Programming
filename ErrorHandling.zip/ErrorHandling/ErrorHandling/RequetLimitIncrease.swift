//
//  RequetLimitIncrease.swift
//  ErrorHandling
//
//  Created by MacStudent on 2018-07-25.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class RequestLimitIncrease{
    var accountInfo = ["S1100" : AcInfo(type: "Saving", balance: 2313.54), "S1200" : AcInfo(type: "Saving", balance: 4500.54), "S1300" : AcInfo(type: "Cheqing", balance: 5313.54), "S1400" : AcInfo(type: "Saving", balance: 7313.54)]
    
    func processrequest(accountNo: String) throws{
        guard let accNo = accountInfo[accountNo]
            else{
             throw limitIncreaseErrors.ineligible
        }
        
        guard accNo.type == "Saving" else{
            throw limitIncreaseErrors.noSavingAc
        }
        
        guard accNo.balance > 5000 else {
            throw limitIncreaseErrors.insufficientBalance
        }
        
        print("Congrats..! Your credit limit is increased.")
    }
}

struct AcInfo{
    var type: String
    var balance: Double
}

enum limitIncreaseErrors: Error{
    case ineligible
    case noSavingAc
    case insufficientBalance
}
