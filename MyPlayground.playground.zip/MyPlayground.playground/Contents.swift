//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

print("Value of str" ,str)

var number = 10
print("Number = ", number)

// str=20
print("Anu","Simran","Prabhjeet",separator: "-")

var sum = number + 20
print("Sum of \(number) and 20 is \(sum)")
//string interpolation

print("😀","🧐","🤯","🙄",separator: "🔨")

var happy = "😂"
print("Happy: \(happy)")

var temp : Int
temp = 30
//print("Temperature : \(temp) cloudy")

if temp < 10{
    print("Cold")
}else if (temp == 30){
    print("Hot")
}else {
    print("Heat alert")
}

let PI : Float = 3.1429
print("PI = \(PI)")

// PI = 2.34

var task : String?

task = "Writing"

if task == nil{
    print("Yay... no task...just fun")
}else{
    print(task!)
}

var taskList : [String]
taskList = ["Singing", "Dancing", "Writing", "Eating", "Sketching"]


for activity in taskList{
    print("Perform \(activity)")
}

var itr = 1
while (itr < 5){
    print("itr: \(itr)")
    itr = itr + 1
}

itr = 10
repeat{
    print("itr : \(itr)")
    itr = itr + 10;
}while(itr <= 30)

itr = 10

switch itr{
case 1...9:
    print("one to nine")
case 10:
    print("Ten")
    fallthrough
case 20:
    print("Twenty")
case 30,40,50:
    print("thirt or forty or fifty")
case 60..<100:
    print("sixty to hundred")
default:
    print("Unreachable")
}







