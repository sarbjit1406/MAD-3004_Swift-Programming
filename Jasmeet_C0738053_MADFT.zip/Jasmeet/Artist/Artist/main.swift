//
//  main.swift
//  Artist
//
//  Created by MacStudent on 2018-07-31.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

var choice = 1
let dataHelper = DataHelper()
var purchase = Purchase()

while choice != 4{
    print("\n----What would you like to do today !----")
    print("\t 1 : Show Arts List ")
    print("\t 2 : Purchase Art ")
    print("\t 3 : Show Purchased Arts ")
    print("\t 4 : Exit ")
    print("-----------------------------------------")
    print("Enter you choice please : ")
    choice = (Int)(readLine()!)!
    
    switch choice{
    case 1:
        print("Show Art list")
        dataHelper.displayArts()
    case 2:
        print("Add purchase")
        purchase.addArt()
    case 3:
        print("Show order")
        print(purchase.display())
    case 4:
        exit(0)
    default:
        print("Please enter valid menu option.")
    }
}



