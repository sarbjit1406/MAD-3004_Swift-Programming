//
//  DataHelper.swift
//  ArtistArt
//
//  Created by MacStudent on 2018-07-31.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

class DataHelper{
    
    var artistList = [String : Artist]()
    var artList = [String : Art]()
    var customerList = [String : Customer]()
    
    init(){
        self.loadArtistList()
         self.loadArtList()
        self.loadCustomerList()
    }
    
    func loadArtistList(){
        artistList = [:]
        
        let a1 = Artist(artistID: "A1", name: "Jonhson", country: "Canada")
        artistList[a1.ArtistId!] = a1
        
        let a2 = Artist(artistID: "A2", name: "Murti", country: "India")
        artistList[a2.ArtistId!] = a2
        
        let a3 = Artist(artistID: "A3", name: "Kape", country: "France")
        artistList[a3.ArtistId!] = a3
        
        let a4 = Artist(artistID: "A4", name: "Anny", country: "America")
        artistList[a4.ArtistId!] = a4
        
        let a5 = Artist(artistID: "A5", name: "Joe", country: "Canada")
        artistList[a5.ArtistId!] = a5
    }
    
    func loadArtList(){
        artList = [:]
        
        let ar1 = Art(artID: "A101", title: "Rangoli Art", category: ArtCategory.Painting, price: 2.50, artistID: "A1", name: "Jonhson", country: "Canada")
        artList[ar1.ArtID!] = ar1
        
        let ar2 = Art(artID: "A102", title: "Wooden Art", category: ArtCategory.Handcrafts, price: 1.51, artistID: "A2", name: "Murti", country: "India")
        artList[ar2.ArtID!] = ar2
        
        let ar3 = Art(artID: "A103", title: "Telephone", category: ArtCategory.Antiques, price: 5.12, artistID: "A3", name: "Kape", country: "France")
        artList[ar3.ArtID!] = ar3
        
        let ar4 = Art(artID: "A104", title: "Pyramids", category: ArtCategory.Skuplture, price: 2.95, artistID: "A4", name: "Anny", country: "America")
        artList[ar4.ArtID!] = ar4
        
        let ar5 = Art(artID: "A105", title: "Hanging frames", category: ArtCategory.Handcrafts, price: 2.55, artistID: "A5", name: "Joe", country: "Canada")
        artList[ar5.ArtID!] = ar5
    }
    
    func displayArts(){
        print("Art List: ")
        Util.drawLine()
        print("\t ID \t\t Title \t\t\t\t Category \t\t Price \t\t Artist")
        for (_, value) in self.artList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print("\t \(value.ArtID!) ------ \(value.Title!) ------ \(value.Category!) ------ \(value.Price!) ------ \(value.Name!)")
        }
        Util.drawLine()
    }
    
    func loadCustomerList(){
        customerList = [:]
        
        let c1 = Customer(customerID: "C1", name: "Jasmeet", address: "Canada, Toronto", contactNo: "416-(455)8756", password: "Jasmeet")
        customerList[c1.CustomerID!] = c1
        
        let c2 = Customer(customerID: "C2", name: "Saini", address: "Canada, Scarbrough", contactNo: "416-(155)9374", password: "Saini")
        customerList[c2.CustomerID!] = c2
    }
    
    func displayCustomers(){
        for (_, value) in self.customerList.sorted(by: { $0.key < $1.key }){
            Util.drawLine()
            print(value.display())
        }
        Util.drawLine()
    }
    
    func searchArt(artID : String) -> Art?{
        if artList[artID] != nil{
            return artList[artID]! as Art
        }
        else{
            print("Sorry..Not available!")
            return nil
        }
    }
}
