//
//  Purchase.swift
//Users/macstudent/Downloads/Artist.swift//  ArtistArt
//
//  Created by MacStudent on 2018-07-31.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

typealias purchaseItem = (artID: String, art: Art, quantity: Int)

class Purchase : Customer{
    private var purchaseID : String?
    private var purchaseDate : Date
    private var orderArts : [purchaseItem]
    private var dataHelper = DataHelper()
    
   
    
    //computed property
    var orderAmount: Double?{
        get{
            var amount = 0.0
            if !self.orderArts.isEmpty{
                for (_, prod, qty) in self.orderArts{
                    amount += prod.Price! * (Double)(qty)
                }
            }
            return amount
        }
    }
    
    override init(){
        super.init()
        self.purchaseID = ""
        self.PurchaseDate = DateFormatter().date(from: "")!
        self.orderArts = []
       
    }
    
    var PurchaseID : String?{
        get { return self.purchaseID }
        set{ self.purchaseID = newValue}
    }
    var PurchaseDate : Date{
        get { return self.purchaseDate }
        set{ self.purchaseDate = newValue}
    }
    
    override func display() -> String {
        var returnData = ""
        
        returnData += "\n Purchase ID : \(self.purchaseID!)"
        returnData += "\n Purchase Date : \(self.purchaseDate )"
               returnData += super.display()
        returnData += "\n Art List : "
        if !self.orderArts.isEmpty
        {
            for (_, art, qty) in self.orderArts{
                returnData += "\n \tArt : \(art.display())"
                returnData += "\n \tQuantity : \(qty)"
            }
        }
        else
        {
            returnData += "\n No arts in the order"
        }
        returnData += "\n Order Amount : \(self.orderAmount  ?? 0.0)"
        
        return returnData
    }
    
    
     func addArt(){
        dataHelper.displayArts()
        print("Please enter art ID to choose from the list : ")
        let selectedArtID : String = (readLine()!)
        
        if let selectedArt = dataHelper.searchArt(artID: selectedArtID)
        {
            self.purchaseID = selectedArtID
            //self.PurchaseDate = Date()
            
            print("How many quantities do you want ? : ")
            let qty : Int = (Int)(readLine()!) ?? 1
            
            self.orderArts += [(artID: selectedArtID, art: selectedArt, quantity: qty)]
            
        }
        else
        {
            print("Sorry...The product you entered is unavailable")
        }
    }
    
    
}
