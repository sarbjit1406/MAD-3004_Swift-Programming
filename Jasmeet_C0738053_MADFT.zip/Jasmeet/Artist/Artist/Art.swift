//
//  Book.swift
//  FinalTestSummer18
//
//  Created by Jigisha Patel on 2018-07-27.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation

typealias classes = (name: String, artistClass: Artist)

class Art : Artist{
    
    private var artID: String?
    private var title : String?
    private var category : ArtCategory?
    private var price : Double?
    
    var ArtID : String?{
        get{ return self.artID }
        set{ self.artID = newValue }
    }
    
    var Title : String?{
        get{ return self.title }
        set{ self.title = newValue }
    }
    
    var Category : ArtCategory?{
        get{ return self.category }
        set{ self.category = newValue }
    }
    
    var Price : Double?{
        get{ return self.price }
        set{ self.price = newValue }
    }
    
    override init(){
        self.artID = ""
        self.title = ""
        self.category = ArtCategory.None
        self.price = 0.0
        super.init()
    }
    
  init(artID: String, title: String, category: ArtCategory, price: Double, artistID: String, name: String, country: String){
        self.artID = artID
        self.title = title
        self.category = category
        self.price = price
        super.init(artistID: artistID, name: name, country: country)
    }
    
    override func display() -> String {
        var returnData = ""
        returnData += "\t \(self.artID ?? "") ------ \(self.title ?? "") ------ \(self.category ?? ArtCategory.None) ------ \(self.Price ?? 0.0)"
        return returnData
    }
}
