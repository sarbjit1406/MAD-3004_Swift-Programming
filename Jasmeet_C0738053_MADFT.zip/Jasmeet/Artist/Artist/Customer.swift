//
//  User.swift
//  FinalTestSummer18
//
//  Created by Jigisha Patel on 2018-07-27.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation
class Customer : IDisplay{
    private var customerID: String?
    private var name : String?
    private var address : String?
    private var contactNo : String?
    private var password : String?
    
    var CustomerID : String?{
        get{ return self.customerID }
        set{ self.customerID = newValue }
    }
    var Name : String?{
        get{ return self.name }
        set{ self.name = newValue }
    }
    
    var Address : String?{
        get { return self.address}
        set {self.address = newValue}
    }
    var ContactNo : String?{
        get { return self.contactNo}
        set {self.contactNo = newValue}
    }
    var Password : String?{
        get { return self.password}
        set {self.password = newValue}
    }
    
    init(){
        self.customerID = ""
        self.name = ""
        self.address = ""
        self.contactNo = ""
        self.password = ""
    }
    
    init(customerID: String, name: String, address: String, contactNo: String, password: String){
        self.customerID = customerID
        self.name = name
        self.address = address
        self.contactNo = contactNo
        self.password = password
    }
    
    func display() -> String{
       
        var returnData = ""
        returnData += "\t \(self.customerID ?? "") ------ \(self.name ?? "") ------ \(self.address ?? "") ------ \(self.contactNo ?? "") ------ \(self.password ?? "")"
        return returnData
    }
    
    func loginCustomer(){
        print("Enter Customer ID : ")
        self.customerID = readLine()!
        print("Enter Password : ")
        self.password = readLine()!
    }
}
