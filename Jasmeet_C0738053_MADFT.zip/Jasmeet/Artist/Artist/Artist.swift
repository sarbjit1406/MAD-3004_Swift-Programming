//
//  Author.swift
//  FinalTestSummer18
//
//  Created by Jigisha Patel on 2018-07-27.
//  Copyright © 2018 JK. All rights reserved.
//

import Foundation
class Artist : IDisplay{
    var artistID: String?
    var name : String?
    var country : String?
    
    var ArtistId : String?{
        get{ return self.artistID }
        set{ self.artistID = newValue }
    }
    
    var Name : String?{
        get{ return self.name }
        set{ self.name = newValue }
    }
    
    var Country : String?{
        get{ return self.country }
        set{ self.country = newValue }
    }
    
    init(){
        self.artistID = ""
        self.name = ""
        self.country = ""
    }
    
    init(artistID: String, name: String, country: String){
        self.artistID = artistID
        self.name = name
        self.country = country
    }
    
    func display() -> String {
        var returnData = ""
        if self.artistID != nil{
            returnData += " ID : " + self.artistID!
        }
        if self.name != nil{
            returnData += "\n Name : " + self.name!
        }
        if self.country != nil{
            returnData += "\n Country : " + self.country!
        }
        return returnData
    }
}
