//
//  main.swift
//  Shopping
//
//  Created by MacStudent on 2018-07-19.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation

print("Hello, World!")

var tejas = Customer()
print(tejas.displayData())

var sarbjit = Customer(customerID: 101, customerName: "Sarbjit", address: "Topeka Rd Toronto", email: "sarbjit@mad.com", creditCardInfo: "4520-0100-1234-5678", shippingInfo: "Ship at lambton college between 1PM to 5PM")
print("\(sarbjit.displayData())")

tejas.CustomerID = 102
tejas.CustomerName = "Tejas"
tejas.Address = "Oshawa"
tejas.Email = "tejas@mad.com"
tejas.CreditCardInfo = "4520-0100-9876-7865"
tejas.ShippingInfo = "Don't deliver between 1PM to 5PM"
print(tejas.displayData())

var navdeep = Customer()
navdeep.registerUser()
print(navdeep.displayData())
