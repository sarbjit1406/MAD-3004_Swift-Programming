//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

var snackItems = [String]()
var items = ["Toronto Potato", "Shaved Ice", "Donuts", "Ice Cream", "French Fries"]
//For displaying the values in index
var snacks : [String]
snacks = ["Toronto Potato", "Shaved Ice", "Donuts", "Ice Cream", "French Fries"]
print("Snacks : \(snacks)")
//For displaying the values
for snack in snacks{
    print("Each day : \(snack)")
}
// For displaying the values in snacks in an array
for snack in 0..<snacks.count{
    print("New day : \(snacks[snack])")
}

for snack in snacks[...2]{
    print("New day one sided range: \(snack)")
}

for snack in snacks[2...]{
    print("New day one sided range: \(snack)")
}
//For index and values:
for (index, value) in snacks.enumerated()
{
    print("Index : \(index) value : \(value)")
}
//To display an array with default values as repeating operator , with value upto 5 values in an array
var numbers = Array(repeating: 1, count: 5)
print("numbers : \(numbers)")
//Modify the vaue in an array
numbers[2] = 25
print("numbers : \(numbers)")

var moreNumbers = Array(repeating: 0, count: 3)
moreNumbers[1] = 878
print("moreNumbers : \(moreNumbers)")

//Addition of two arrays
var allNumbers = numbers + moreNumbers
allNumbers[5] = 100
print("allNumbers : \(allNumbers)")
//Adding more elements in an array by using += operator and append properties
var grocery = ["Pringles","Juice"]
grocery += ["Fruits","Chocolates"]
grocery.append("Tomotoes")
grocery.append("Rice")
print("Grocery : \(grocery)")

grocery[1...3] = ["Milk", "Veggies", "Mayo", "Chipotle", "Bread"]
print("Grocery : \(grocery)")
// Insert operation:
grocery.insert("Ice cream", at:1)
print("Grocery : \(grocery)")
// removing the value
grocery.remove(at: 7)
grocery.removeLast()
print("Grocery : \(grocery)")

grocery.removeAll()
if grocery.isEmpty{
    print("Everything in kitchen")
}else{
    print("Go back to the market")
}

var rajnikanth = [Any]()

rajnikanth.append("Robot")
rajnikanth.append(2.0)
rajnikanth.append(1)
print("Rajnikanth : \(rajnikanth)")

//Set
var languages = Set<String>()
languages.insert("Gujarati")
languages.insert("Hindi")
languages.insert("English")
languages.insert("Pujabi")
languages.insert("Telgu")
languages.insert("Sanskrit")

print("Languages : \(languages)")
languages.remove("Sanskrit")
print("Telgu is available in class : \(languages.contains("Telgu"))")
print("Sanskrit is available in class : \(languages.contains("Sanskrit"))")

for lang in languages.sorted(){
    print("language : \(lang)")
}

let motherTongue : Set = ["Gujarati", "Punjabi", "Urdu", "Hindi", "Telgu", "Marathi"]
print("MotherTongue : \(motherTongue)")

print("Union : \(languages.union(motherTongue).sorted())")
print("Interection : \(languages.intersection(motherTongue).sorted())")
print("Symmetric difference : \(languages.symmetricDifference(motherTongue).sorted())")
print("Substracting 1 - 2 : \(languages.subtracting(motherTongue).sorted())")
print("Substracting 2 - 1 : \(languages.subtracting(motherTongue).sorted())")

var commonLangs = languages.intersection(motherTongue).sorted()
    print("Common langs : \(commonLangs)")
    print(languages.isSubset(of: commonLangs))
    print(languages.isSuperset(of: commonLangs))
    print(motherTongue.isDisjoint(with: languages))

//Dictionary
//Type of key : type of value [String : String]
var appreciation = [String : String] ()
appreciation["Day 1"] = "Potato Tornoado"
appreciation["Day 3"] = "Donuts"
print("appreciation : \(appreciation)")

print("\(appreciation.count) appreciation days")

//appreciation = [:]
if appreciation.isEmpty{
    print("No appreciation 😡... just studies")
}
//value will be added at the end
appreciation["Day 2"] = "Shaved Ice"
print("appreciation : \(appreciation)")

let oldItem = appreciation.updateValue("Gola", forKey: "Day 2")
print("appreciation : \(appreciation)")
print("oldItem : \(oldItem!)")

if let day4Item = appreciation["Day 4"]{
print("day4Item : \(day4Item)")
}else{
print("Nothing for day 4")
}

appreciation["Day 4"] = "Ice Cream"

if let removedValue = appreciation.removeValue(forKey: "Day 3"){
    print("\(removedValue) are no longer available")
    print("appreciation : \(appreciation)")
}else{
    print("Nothing found for Day 3")
}

appreciation["Day 2"] = nil
print("appreciation : \(appreciation)")
for app in appreciation.keys{
    print("app key : \(app)")
}
for app in appreciation.values{
    print("app values : \(app)")
}
for(key, value) in appreciation{
    print("key : \(key) value : \(value)")
}
var flight = [String : AnyObject]()
flight["number"] = "9W 234" as AnyObject
flight["number"] = 16 as AnyObject
flight["cost"] = 1000.34 as AnyObject

print("flight : \(flight)")
